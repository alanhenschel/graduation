#include <stdio.h>
#include <stdlib.h>
#include "largura.h"


void main() {

	node *raiz;

	int matriz[3][3] = {1,2,3,0,7,4,6,8,5};
	int matriz2[3][3] = {1,2,3,8,0,4,7,6,5};


	int teste = 0;

	teste = funcao(matriz2);

	printf("%d\n", teste);


		int aux[3][3];
	int count = 100000000;

	for(int i = 0; i < 3; i++) {
		for(int j = 0; j < 3; j++) {


				aux[i][j] = (teste/count);
				teste = teste - ((teste/count)*count); 
				count = count/10;

		}
	}



	for(int i = 0; i < 3; i++) {
		for(int j = 0; j < 3; j++) {
			printf("%d ", aux[i][j]);
		}
		printf("\n");
	}





}