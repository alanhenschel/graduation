#include <stdio.h>
#include <stdlib.h>
#include "largura.h"


node *gera_estado(node *raiz, int matriz[][3]) {


	if(raiz == NULL) {

		raiz =  malloc(sizeof(node));
	}
}

int achar_i(int matriz[][3]) {


		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {

				if(matriz[i][j] == 0) {

					return i;
				}

			}
		}
}

int achar_j(int matriz[][3]) {


		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {

				if(matriz[i][j] == 0) {

					return j;

				}

			}
		}

}

int funcao(int matriz[][3]) {

	int aux = 0;
	int count = 100000000;

	for(int i = 0; i < 3; i++) {
		for(int j = 0; j < 3; j++) {


				aux = (aux + count*matriz[i][j]);
				count = count/10;

		}
	}
	return aux;
}




int verificar(int mat1[][3], int mat2[][3]) {

	for(int i = 0; i < 3; i++) {
		for(int j = 0; j < 3; j++) {
			if(mat1[i][j] != mat2[i][j])
				return 0;
		}
	}
	return 1;
}
