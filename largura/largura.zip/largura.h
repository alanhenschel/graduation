#include <stdio.h>
#include <stdlib.h>


typedef struct node{

	int num;
	struct node *down;
	struct node *up;
	struct node *left;
	struct node *right;
}node;

node *gera_estado(node *raiz, int matriz[][3]);
int funcao(int matriz[][3]);